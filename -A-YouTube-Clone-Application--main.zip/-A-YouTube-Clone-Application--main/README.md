# -A-YouTube-Clone-Application-
YouTube Clone is an efficacious video-sharing solution that aids you in launching your video streaming software that has the power to rival YouTube itself. The app allows admin to add an unlimited collection of videos to keep the users hooked to the app.
